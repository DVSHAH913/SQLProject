SET LINESIZE 200;
accept fd date format 'dd/mm/yyyy' prompt 'Date (dd/mm/yyyy): '
select tdate,s.sname as Script_Name,c.name,(case when t.bs='B' then qty else 0 end) as BUY_QTY,(case when t.bs='B' then (qty*rate) else 0 end) as BUY_AMONT,(case when t.bs='S' then (qty) else 0 end) as SELL_QTY,(case when t.bs='S' then (qty*rate) else 0 end) as SELL_AMONT from transaction t inner join clientmaster c on c.ccode=t.ccode  inner join scriptmaster s on s.scode=t.scode where t.tdate=to_date('&fd','dd/mm/yyyy') order by c.name,s.sname;
